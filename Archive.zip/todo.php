	
<?php 
session_start();


require('head.php');
if($_POST){
	header('location:index.php?app=todo');// TO STOP REFRESH FROM POSTING LAST POST		

}


	if(isset($_SESSION['lists'])){
        $_SESSION['lists'][] = $_POST['todoinput'];
   }else{
	    $_SESSION['lists'] = [];
   }



?>


    <form method="POST">
			<input type="text" name="todoinput" id="todoinput" required>
			<input type="submit" value="Add activity" class="button" id="submit">
	</form>

	<ul class="ul">

		
		
		<?php
		
		
		foreach($_SESSION['lists'] as $items){
			if($items != "")// SANITIZED HERE
			echo "<li><i class='fas fa-asterisk'></i>&nbsp;&nbsp;&nbsp;$items<a href='index.php?action=alarm'><span class='fas fa-bell right'></span></a></li>";
		}
		
		
		
		?>

		
	</ul>

    <div class="preupgrade">
        <a href="index.php?action=delete-all" id="deleteall"><i class="fas fa-trash-alt"></i></a>
        <span class="countstatus">&check;Complete</span>&nbsp;&nbsp;<span id='count1'>0</span>&nbsp;&nbsp;
        <span class="countstatus">&lotimes;&nbsp;In Progress</span>&nbsp;&nbsp;<span id='count2'>0</span>&nbsp;&nbsp;
        <span class="countstatus">&ofcir;&nbsp;Pending</span>&nbsp;&nbsp;<span id='count3'>0</span>&nbsp;&nbsp;
     </div>
