///////////////////////////////////TODO//////////////////////////
let changer = false;
let btag = document.querySelector('b');
var count1 = document.getElementById('count1');
var count2 = document.getElementById('count2');
var count3 = document.getElementById('count3');
const s1 = document.getElementById('select1');/////TIME SELECT H
const s2 = document.getElementById('select2');/////TIME SELECT M
let sound1 = document.getElementById('alarm1');



let Lis = document.getElementsByTagName('li');
for(let i =0; i < Lis.length; i++){
	
	Lis[i].addEventListener('click', (e)=>{
		//GET THE INDEX OF CLICKED LI TAGS
        if(e.target.tagName == 'LI'){
		let myKey = Array.from(e.target.closest('ul').children);
		let keyIndex = myKey.indexOf(e.target);
		//CREATE A TOGGLE THAT STORES INDEX AND ASSIGN A VALUE OF 1 OR 0 IN SESSIONSTORAGE
		if(changer == false){
			sessionStorage.setItem(keyIndex , 1 );
			changer = true;
		}else{
			sessionStorage.setItem(keyIndex , 0 );
			changer = false;
		}
        }
	})
    

}


//REFRESH THE LI TAGS WITH SESSION STORAGE UPDATE EVERY FRACTION
let checker = document.getElementsByTagName('span');
//checker.style.color ='white';


/////////////////////////////////////////////////////////////////
setInterval(()=>{
	for(let u = 0; u < sessionStorage.length; u++ ){
		if(sessionStorage.getItem(sessionStorage.key(u)) == 1){
		      Lis[sessionStorage.key(u)].style.backgroundColor = 'tomato';
			  Lis[sessionStorage.key(u)].style.borderBottomColor = 'orange';
			  Lis[sessionStorage.key(u)].style.color = 'white';
			  Lis[sessionStorage.key(u)].style.opacity = '1';
			  checker[sessionStorage.key(u)].className = 'fas fa-power-off power';
			  Lis[sessionStorage.key(u)].appendChild(checker[sessionStorage.key(u)]);
			  Lis[sessionStorage.key(u)].style.animation = '1s flash';
              

			
			
			
			
			
			
			
		   }else if(sessionStorage.getItem(sessionStorage.key(u)) == 0){
			  Lis[sessionStorage.key(u)].style.backgroundColor = 'seagreen';
			  Lis[sessionStorage.key(u)].style.borderBottomColor = 'orange';
			  Lis[sessionStorage.key(u)].style.color = 'white';
			  Lis[sessionStorage.key(u)].style.opacity = '0.7';
			  checker[sessionStorage.key(u)].className = 'fas fa-check-double';
			  Lis[sessionStorage.key(u)].appendChild(checker[sessionStorage.key(u)]);
		   }
	}
	
	btag.textContent = newDate();///UPDATE THE DATE
    ////////////////////////////////////////////////////////////////////
    countStatus('seagreen' , count1);
    countStatus('tomato' , count2);///////////UPDATES COMPLETED INPROGRESS & PENDING
    countStatus('',count3);
    ///////////////////////////////////////////////////////////////////////////////////
})////////SETINTERVAL ENDS/////////


//////DATE FUNCTION//////////
let newDate = ()=>{
	let i = new Date();
	let h = i.getHours();
	let m = i.getMinutes();
	let s = i.getSeconds();
	let output = h+":"+m+":"+s;
	return output;
}

/////////DETECTS THE ACTIVITIES IN PROGRESS
/*let detector = ()=>{
    for(let i = 0; i < Lis.length; i++){
        if(Lis[i].style.backgroundColor == 'tomato'){
            setTimeout(()=>{
                Lis[i].style.animation = '10s fadeIn';
            },4000);
            
           }
    }
}*/
//setInterval(detector , 1000);

///////////////CLEAR SESSIONSTORAGE
let clearSession = ()=>{
    let del = document.getElementById('deleteall');
     del.addEventListener('click',()=>{
         let i = confirm('Are you sure you want to clear this Session?');
         if(i == true){
             sessionStorage.clear();
         }
     })
}
clearSession();

///////// COUNT STATUS UPDATE//////////////////////////////////////
let countStatus = (myColor , myTarget)=>{
    var num = [];
    for(let i =0; i < Lis.length; i++){
        if(Lis[i].style.backgroundColor == myColor){
           num.push(i);
           }
    }
    myTarget.textContent = num.length;
}


////////////////////////////////////////////////////////////////////


////////////////////////////////////////////ALARM//////////////////////////
let alarm = (Htime ,Mtime, message)=>{
    let date = new Date();
    let h = date.getHours();
    let m = date.getMinutes();
        if(Htime == h && Mtime == m){
           console.log(message);
            sound1.play();
           }
}
let button = document.getElementById('setalarm');
button.addEventListener('click',(e)=>{
    setInterval(()=>{
      alarm( s1.value , s2.value , 'change this to li textcontent for notification');  
    })
})
///////////////////////////////////////////////ALARM/////////////////////////












